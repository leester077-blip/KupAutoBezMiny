# KUP AUTO BEZ MINY — v0.9.2 ENGINE PICKER UX

Hotfix/UX po testach v0.9.1 na telefonie.

Zmiany:
- wszystkie popularne silniki są widoczne od razu w siatce, bez poziomego przewijania,
- silniki pogrupowane: Benzyna / Diesel / Hybryda / Elektryk,
- szybkie filtry paliwa z liczbą dostępnych wersji,
- wybrany silnik podświetla się na złoto i dostaje znak ✓,
- wybór silnika automatycznie ustawia rodzaj paliwa dla dalszej checklisty,
- ręczne pole silnika przeniesione pod picker jako opcja awaryjna,
- Passat B8/Golf VII/Tiguan II/Superb III uzupełnione o popularne PHEV,
- tryb oględzin przesunięty logicznie do KROKU 3.

versionCode: 11
versionName: 0.9.2
