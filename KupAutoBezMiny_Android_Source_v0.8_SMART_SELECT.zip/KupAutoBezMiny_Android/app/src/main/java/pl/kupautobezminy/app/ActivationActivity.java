package pl.kupautobezminy.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public class ActivationActivity extends Activity {
    private static final String PREFS = "kabm_license";
    private static final String TEST_CODE = "KABM-TEST-2026";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyImmersiveMode();

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (prefs.getBoolean("activated", false)) {
            openApp();
            return;
        }

        setContentView(R.layout.activity_activation);

        EditText codeInput = findViewById(R.id.codeInput);
        Button activateButton = findViewById(R.id.activateButton);
        TextView errorText = findViewById(R.id.errorText);
        TextView deviceIdText = findViewById(R.id.deviceIdText);

        String deviceKey = deviceKey();
        deviceIdText.setText("ID urządzenia: " + deviceKey + "\nWersja testowa — finalnie kod będzie sprawdzany online i przypisywany do licencji.");

        activateButton.setOnClickListener(v -> {
            String code = codeInput.getText().toString().trim().toUpperCase(Locale.ROOT);
            if (TEST_CODE.equals(code)) {
                prefs.edit()
                        .putBoolean("activated", true)
                        .putString("activation_code", code)
                        .putString("device_key", deviceKey)
                        .apply();
                openApp();
            } else {
                errorText.setText("Nieprawidłowy kod. Kod testowy tej wersji: KABM-TEST-2026");
                errorText.setVisibility(View.VISIBLE);
            }
        });
    }

    private void applyImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyImmersiveMode();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersiveMode();
    }

    private void openApp() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }

    private String deviceKey() {
        try {
            String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest((id + ":kup-auto-bez-miny").getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format(Locale.ROOT, "%02X", hash[i]));
            return sb.toString();
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }
}
