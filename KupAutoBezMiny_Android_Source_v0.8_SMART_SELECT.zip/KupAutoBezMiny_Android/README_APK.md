# Kup Auto Bez Miny — Android test build

To jest pierwszy projekt natywnego opakowania Android dla aplikacji „Kup Auto Bez Miny”.

## Co jest już przygotowane
- pełny ekran WebView z aplikacją v2.6 w assets/index.html,
- JavaScript + localStorage + IndexedDB,
- aparat / wybór zdjęcia z telefonu,
- natywny wydruk / zapis raportu do PDF przez system Android,
- ekran aktywacji przed wejściem do aplikacji,
- lokalny identyfikator urządzenia,
- kod developerski do pierwszych testów: `KABM-TEST-2026`.

## Ważne
Kod testowy NIE jest zabezpieczeniem sprzedażowym. Finalna wersja musi wysyłać kod aktywacyjny + identyfikator urządzenia do naszego API HTTPS. Serwer będzie przechowywał licencję, limit urządzeń (np. 1 lub 2), status aktywacji oraz możliwość unieważnienia urządzenia.

## Docelowy przebieg licencji
1. Klient kupuje dostęp.
2. System generuje jednorazowy kod licencji.
3. Aplikacja wysyła kod + ID urządzenia do API.
4. API sprawdza liczbę aktywnych urządzeń.
5. Po poprawnej odpowiedzi aplikacja zapisuje token aktywacyjny lokalnie.
6. Aplikacja działa offline; okresowo może odświeżyć ważność licencji online.

## Kompilacja
Projekt jest standardowym projektem Android/Gradle. Otwórz katalog główny w Android Studio i zbuduj wariant debug lub release.

## Automatyczna kompilacja w GitHub Actions
Projekt zawiera `.github/workflows/android-apk.yml`.
Po umieszczeniu repozytorium na GitHubie workflow:
- przygotowuje Java 17,
- przygotowuje Gradle 8.9,
- instaluje Android SDK 35,
- buduje `app-debug.apk`,
- publikuje go jako artifact `KupAutoBezMiny-test-apk`.

To pozwala zbudować APK bez lokalnego Android Studio.
