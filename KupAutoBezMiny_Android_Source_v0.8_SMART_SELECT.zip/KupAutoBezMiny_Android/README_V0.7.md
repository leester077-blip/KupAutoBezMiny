# Kup Auto Bez Miny — v0.7 MODEL EXPERT

Najważniejsze zmiany:
- versionCode 7 / versionName 0.7.0 — aktualizacja na podpisaną v0.6,
- MODEL EXPERT: 26 profili popularnych modeli/generacji, dopasowanych po marce, modelu i roczniku,
- dodatkowe punkty kontrolne dotyczące nadwozia, elektroniki, zawieszenia, asystentów, AWD i skrzyń występujących w danej generacji,
- każdy punkt MODEL EXPERT można oznaczyć: OK / Wątpliwe / Problem / Nie sprawdzono,
- oceny modelowe są zapisywane lokalnie osobno dla oględzin,
- punkty modelowe wpływają na kompletność i werdykt DECYZJI PRO,
- problemy modelowe trafiają do NEGOCJATORA PRO jako argumenty,
- profil modelu i oceny są widoczne w raporcie końcowym / tekście raportu,
- zachowany SMART CHECK silnika, mapa nadwozia, zdjęcia, koszty, zapis, porównanie i raport PDF.

MODEL EXPERT jest listą priorytetów kontrolnych dla generacji pojazdu, a nie diagnozą ani gwarancją występowania konkretnych usterek.
