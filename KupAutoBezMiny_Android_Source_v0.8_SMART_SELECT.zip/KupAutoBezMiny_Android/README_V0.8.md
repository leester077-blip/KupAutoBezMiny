# Kup Auto Bez Miny — v0.8 SMART SELECT

Najważniejsze zmiany:
- versionCode 8 / versionName 0.8.0 — aktualizacja na podpisaną v0.7,
- SMART SELECT: automatyczne podpowiedzi marek podczas pisania,
- lista modeli/generacji filtrowana po wybranej marce,
- wybór modelu jednym kliknięciem automatycznie uruchamia MODEL EXPERT,
- wyraźne złote potwierdzenie rozpoznanego auta,
- popularne auta jako szybkie kafelki,
- ostatnio wybierane modele zapisują się lokalnie i są dostępne jednym kliknięciem,
- nadal można wpisać markę/model ręcznie — rozpoznawanie działa wstecznie jak w v0.7,
- zachowane: MODEL EXPERT (26 profili), SMART CHECK silnika, DECYZJA PRO, NEGOCJATOR PRO, mapa nadwozia, zdjęcia, koszty, zapis, porównanie i raport.

SMART SELECT ma skrócić drogę od uruchomienia aplikacji do właściwej checklisty i zmniejszyć ryzyko literówek w nazwie modelu.
