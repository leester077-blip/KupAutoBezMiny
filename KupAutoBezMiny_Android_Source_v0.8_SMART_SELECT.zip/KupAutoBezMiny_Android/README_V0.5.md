# Kup Auto Bez Miny — v0.5 SMART

Najważniejsze zmiany:
- stały package `pl.kupautobezminy.app`, versionCode 5, versionName 0.5.0,
- SMART CHECK: dopasowanie typowych obszarów kontroli na podstawie marki/modelu/silnika,
- pierwsza baza 15 popularnych rodzin napędów spotykanych na polskim rynku,
- praktyczne wskazówki „jak sprawdzić” bez udawania diagnozy,
- profil wersji trafia także do raportu/PDF i kopiowanego podsumowania,
- zachowane tryby SZYBKIE / PEŁNE PRO, mapa nadwozia, zdjęcia, notatki, koszty, zapis i porównanie aut.

Uwaga: SMART CHECK wskazuje obszary do kontroli. Nie potwierdza usterki i nie zastępuje diagnostyki.
