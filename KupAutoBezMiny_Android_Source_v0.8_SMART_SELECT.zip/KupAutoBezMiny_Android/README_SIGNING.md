# KABM stable signing (v0.3+)

This project is configured for release signing via environment variables:
- KABM_KEYSTORE_PATH
- KABM_KEYSTORE_PASSWORD
- KABM_KEY_ALIAS
- KABM_KEY_PASSWORD

Do not commit the keystore or passwords to GitHub.
The GitHub Actions workflow reconstructs the keystore from a repository secret and builds app-release.apk.
