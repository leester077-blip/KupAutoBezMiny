# Kup Auto Bez Miny v0.4 — UX BOOST

Zmiany:
- tryb SZYBKI (~30 kluczowych kontroli, czerwone flagi zawsze widoczne)
- tryb PEŁNE PRO (pełna checklista)
- interaktywna mapa 11 elementów nadwozia
- opcjonalny zapis pomiarów lakieru w µm dla mapy
- podsumowanie mapy nadwozia w raporcie / PDF
- pole Silnik / wersja przygotowujące bazę typowych usterek
- czytelny wskaźnik aktywnego trybu w każdej sekcji
- zachowany fullscreen oraz konfiguracja stałego podpisu release z v0.3

Uwaga: wartości µm należy porównywać między elementami i stronami auta. Pojedynczy pomiar nie jest samodzielnym dowodem naprawy.
