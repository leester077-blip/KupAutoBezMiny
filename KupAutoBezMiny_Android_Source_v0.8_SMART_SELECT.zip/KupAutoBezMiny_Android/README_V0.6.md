# Kup Auto Bez Miny — v0.6 DECISION

Najważniejsze zmiany:
- versionCode 6 / versionName 0.6.0 — aktualizacja na podpisaną v0.5,
- DECYZJA PRO: dynamiczny werdykt dalszego działania na podstawie czerwonych flag, problemów, wątpliwości i kompletności,
- nowa kompletność liczona tylko z punktów właściwych dla wybranego trybu, napędu i skrzyni,
- NEGOCJATOR PRO: cena auta + koszty wpisane przez użytkownika + opcjonalna rezerwa,
- matematyczny punkt odniesienia do negocjacji bez udawania automatycznej wyceny rynkowej,
- własna propozycja ceny, różnica kwotowa i procentowa,
- automatyczny tekst negocjacji z zaznaczonych problemów i wpisanych kosztów,
- decyzja i dane negocjatora są uwzględniane w kopiowanym/udostępnianym raporcie,
- zachowany SMART CHECK v0.5, mapa nadwozia, zdjęcia, koszty, zapis oględzin, porównanie i raport PDF.

Ważne: rekomendacja aplikacji jest wsparciem decyzji i nie zastępuje diagnostyki warsztatowej ani wyceny rzeczoznawcy.
