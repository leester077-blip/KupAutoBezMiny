# Kup Auto Bez Miny — v0.10 PRODUCT POLISH

Najważniejsze zmiany:

- START PRO: karta gotowości danych auta przed rozpoczęciem oględzin.
- Baza MODEL EXPERT rozszerzona z 28 do 47 profili popularnych generacji.
- ENGINE PICKER rozszerzony o silniki dla nowych profili.
- Podsumowanie decyzyjne na początku raportu: werdykt, kompletność, problemy, czerwone flagi, koszty i priorytety.
- Dopracowane teksty, wersjonowanie i prezentacja produktu.
- Zachowane: SMART SELECT, SMART CHECK, MODEL EXPERT, DECYZJA PRO, NEGOCJATOR PRO, mapa nadwozia, zdjęcia/notatki, zapis oględzin, porównanie i PDF/druk.

Android: versionCode 12, versionName 0.10.0.
