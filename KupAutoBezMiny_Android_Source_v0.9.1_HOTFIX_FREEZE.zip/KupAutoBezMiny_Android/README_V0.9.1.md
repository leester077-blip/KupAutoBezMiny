# Kup Auto Bez Miny v0.9.1 — SMART ENGINE HOTFIX

Poprawka krytyczna:
- usunięto zapętlenie MutationObserver w liście modeli SMART SELECT, które mogło blokować aplikację po wyborze marki (np. Audi),
- przepisywanie nazw generacji wykonuje się teraz tylko raz dla danego elementu,
- obserwator reaguje wyłącznie na wymianę listy modeli, a nie na własne zmiany wewnątrz elementów,
- zachowane wszystkie funkcje v0.9 SMART ENGINE SELECT.

Android: versionCode 10, versionName 0.9.1.
