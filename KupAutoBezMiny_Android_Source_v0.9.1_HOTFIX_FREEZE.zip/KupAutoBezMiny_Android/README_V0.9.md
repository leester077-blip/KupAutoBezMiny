# Kup Auto Bez Miny v0.9 — SMART ENGINE SELECT

Zmiany:
- czytelniejsze nazwy modeli/generacji w SMART SELECT (np. BMW Seria 5 — F10/F11),
- po rozpoznaniu modelu pojawia się lista popularnych silników jako przyciski,
- wybrany silnik jest podświetlany i automatycznie trafia do pola „Silnik / wersja”,
- jednostki z istniejącym profilem SMART CHECK są oznaczone etykietą SMART CHECK,
- status potwierdza, czy dedykowany profil silnika został uruchomiony,
- ręczne wpisywanie silnika nadal działa,
- lista silników jest pomocą wyboru i nie zastępuje identyfikacji po VIN.

Android: versionCode 9, versionName 0.9.0.
